# My first time using python.
#
# Thank you https://www.w3schools.com
# I learned from there, very helpful stuff.
# 

if 5 > 2:
  print("Five is greater than two btw!")

x = 5
y = "This is y"
z = 69420

print(x)
print(y)
print(z)

a = str(3)
b = int(3)
c = float(3)

print(a)
print(b)
print(c)

e = "Python is "
f = "awesome!"
g =  e + f
print(g)

i = 1
while i < 10:
  print(i)
  i += 1